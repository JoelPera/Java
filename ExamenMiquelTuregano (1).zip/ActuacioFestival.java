import java.time.LocalDate;
import java.io.Serializable;

public class ActuacioFestival extends Actuacio implements Serializable{
    private String nomFestival;
    private String escenari;

    public ActuacioFestival(String id, String nomGrup, LocalDate data, double preuBase, String nomFestivak,
            String escenari) {
        super(id, nomGrup, data, preuBase);
        this.nomFestival = nomFestivak;
        this.escenari = escenari;
    }

    public String getNomFestival() {
        return nomFestival;
    }

    public void setNomFestival(String nomFestival) {
        this.nomFestival = nomFestival;
    }

    public String getEscenari() {
        return escenari;
    }

    public void setEscenari(String escenari) {
        this.escenari = escenari;
    }
    @Override
    public double calcularPreuFinal(){
        return getPreuBase() + 20;
    }
    @Override
    public String getTipus(){
        return "Festival";
    }
    @Override 
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", nomFestival=").append(getNomFestival()).append(", escenari=")
        .append(getEscenari()).append(", costFinal=").append(calcularPreuFinal()).append("]");
        return sb.toString();
    }
}
