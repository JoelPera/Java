import java.time.LocalDate;

import exceptions.ActuacioDuplicadaException;
import exceptions.ActuacioNoExisteixException;

public class MainTest {
    public static void main(String[] args) {
        GestorActuacions gestor = new GestorActuacions("MusicCat");

        System.out.println("--- Afegir actuacions ---");

        System.out.println("\n--- Totes les actuacions ---");
        gestor.mostrarActuacions();

        System.out.println("\n--- Festivals ---");
        gestor.mostrarSegonsTipus("Festival");

        System.out.println("\n--- Concerts ---");
        gestor.mostrarSegonsTipus("Concert");

        System.out.println("\n--- Tots ---");
        gestor.mostrarSegonsTipus("Tots");
        
    }
}
