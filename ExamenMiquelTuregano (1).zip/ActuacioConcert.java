import java.time.LocalDate;
import java.io.Serializable;

public class ActuacioConcert extends Actuacio implements Serializable {
    private String sala;
    private int aforament;

    public ActuacioConcert(String id, String nomGrup, LocalDate data, double preuBase, String sala, int aforament) {
        super(id, nomGrup, data, preuBase);
        this.sala = sala;
        this.aforament = aforament;
    }

    public String getSala() {
        return sala;
    }

    public void setSala(String sala) {
        this.sala = sala;
    }

    public int getAforament() {
        return aforament;
    }

    public void setAforament(int aforament) {
        this.aforament = aforament;
    }

    @Override
    public double calcularPreuFinal() {
        return getPreuBase() + (aforament * 2);
    }

    @Override
    public String getTipus() {
        return "Concert";
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", sala=").append(getSala()).append(", aforament=")
                .append(getAforament()).append(", costFinal=").append(calcularPreuFinal()).append("]");
        return sb.toString();
    }
}
