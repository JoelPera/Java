import java.time.LocalDate;
import java.io.Serializable;

public abstract class Actuacio implements Comparable<Actuacio>, Serializable{
    private String id;
    private String nomGrup;
    private LocalDate data;
    private double preuBase;

    public Actuacio() {
    }

    public Actuacio(String id, String nomGrup, LocalDate data, double preuBase) {
        this.id = id;
        this.nomGrup = nomGrup;
        this.data = data;
        this.preuBase = preuBase;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNomGrup() {
        return nomGrup;
    }

    public void setNomGrup(String nomGrup) {
        this.nomGrup = nomGrup;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public double getPreuBase() {
        return preuBase;
    }

    public void setPreuBase(double preuBase) {
        this.preuBase = preuBase;
    }
    public abstract double calcularPreuFinal();
    public String getTipus(){
        return "Tots";
    };
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("[codi=").append(id).append(", grup=").append(nomGrup)
        .append(", data=").append(data).append(", cacheBase=").append(preuBase);
        return sb.toString();
    }
    @Override
    public int compareTo (Actuacio a){
        return this.getId().compareTo(a.getId());
    }
}
