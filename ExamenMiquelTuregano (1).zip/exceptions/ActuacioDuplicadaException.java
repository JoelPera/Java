package exceptions;


public class ActuacioDuplicadaException extends RuntimeException{
    public ActuacioDuplicadaException(String ms){
        super(ms);
    }
}
