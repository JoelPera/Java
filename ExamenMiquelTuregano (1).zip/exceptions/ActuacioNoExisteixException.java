package exceptions;

public class ActuacioNoExisteixException extends RuntimeException{
    public ActuacioNoExisteixException(String ms){
        super(ms);
    }
}
