import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.TreeMap;
import java.io.Serializable;


import exceptions.ActuacioDuplicadaException;
import exceptions.ActuacioNoExisteixException;

import java.util.Map.Entry;

public class GestorActuacions implements Serializable{
    private String nom;
    private TreeMap<String, Actuacio> gestor = new TreeMap<>();

    public GestorActuacions(String nom) {
        this.nom = nom;
    }

    public void afegirActuacio(Actuacio a) {
        if (gestor.containsKey(a.getId())) {
            throw new ActuacioDuplicadaException("Error: Ja existeix una Actuacio amb el codi" + a.getId());
        }
        gestor.put(a.getId(), a);
    }

    public void mostrarActuacions() {
        for (Entry<String, Actuacio> a : gestor.entrySet()) {
            System.out.println(a.getValue() + "\n");
        }
    }

    public Actuacio cercarPerCodi(String id) {
        if (!gestor.containsKey(id)) {
            throw new ActuacioNoExisteixException("Error: No existeix cap Actuacio amb el codi" + id);
        }
        return gestor.get(id);
    }

    public void eliminarActuacio(String id) {
        if (!gestor.containsKey(id)) {
            throw new ActuacioNoExisteixException("Error, no existeix aquest recurs.");
        }
        gestor.remove(id);
    }

    public void mostrarSegonsTipus(String tipus) {
        if (tipus.equals("Concert")) {
            mostraConcert();
        } else if (tipus.equals("Festival")) {
            mostraFestival();
        } else {
            mostrarActuacions();
        }
    }

    public void mostraConcert() {
        ArrayList<Actuacio> tots = new ArrayList<>();
        tots.addAll(gestor.values());
        System.out.println("ActuacioConcert[");
        for (Actuacio a : tots) {
            if (a.getTipus().equals("Concert")) {
                System.out.println(a);
            }
        }
        System.out.println("]\n");
    }

    public void mostraFestival() {
        ArrayList<Actuacio> tots = new ArrayList<>();
        tots.addAll(gestor.values());
        System.out.println("ActuacioFestival[");
        for (Actuacio a : tots) {
            if (a.getTipus().equals("Festival")) {
                System.out.println(a);
            }
        }
        System.out.println("]\n");
    }

    public void mostrarCostSuperiorA(int cost) {
        ArrayList<Actuacio> tots = new ArrayList<>();
        tots.addAll(gestor.values());
        for (Actuacio a : tots) {
            if (a.calcularPreuFinal() > 50) {
                System.out.println(a);
            }
        }
    }

    public void guardar(String f) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
            oos.writeObject(gestor);
        } catch (IOException e) {
            System.out.println("Error en guardar " + e.getMessage());
        }
    }

    public void carregar(String f) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            gestor = (TreeMap<String, Actuacio>) ois.readObject();
        } catch (IOException e) {
            System.out.println("Error en carregar " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Fitxer no trobat" + e.getMessage());
        }
    }
}
