import java.time.LocalDate;

import exceptions.ActuacioDuplicadaException;
import exceptions.ActuacioNoExisteixException;

public class MainExamen {
    public static void main(String[] args) {
        GestorActuacions gestor = new GestorActuacions("MusicCat");

        System.out.println("--- Afegir actuacions ---");
        try {
            gestor.afegirActuacio(new ActuacioFestival(
                    "F001",
                    "Pony Pisador",
                    LocalDate.of(2025, 7, 15),
                    500,
                    "Canet Rock",
                    "Escenari Principal"));
            System.out.println("Actuació amb codi F001 afegida correctament.");

            gestor.afegirActuacio(new ActuacioFestival(
                    "F002",
                    "Doctor Prats",
                    LocalDate.of(2025, 7, 20),
                    800,
                    "Acampada Jove",
                    "Escenari Jove"));
            System.out.println("Actuació amb codi F002 afegida correctament.");

            gestor.afegirActuacio(new ActuacioConcert(
                    "C001",
                    "Els Catarres",
                    LocalDate.of(2025, 6, 10),
                    300,
                    "Sala Apolo",
                    200));
            System.out.println("Actuació amb codi C001 afegida correctament.");

            gestor.afegirActuacio(new ActuacioConcert(
                    "C002",
                    "Mishima",
                    LocalDate.of(2025, 6, 15),
                    400,
                    "Razzmatazz",
                    500));
            System.out.println("Actuació amb codi C002 afegida correctament.");

            gestor.afegirActuacio(new ActuacioFestival(
                    "F001",
                    "Stay Homas",
                    LocalDate.of(2025, 7, 25),
                    600,
                    "Cruïlla",
                    "Escenari Principal"));
            System.out.println("Actuació amb codi F001 afegida correctament.");

        } catch (ActuacioDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\n--- Totes les actuacions ---");
        gestor.mostrarActuacions();

        System.out.println("\n--- Cercar ---");
        try {
            System.out.println(gestor.cercarPerCodi("C001"));
        } catch (ActuacioNoExisteixException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            System.out.println(gestor.cercarPerCodi("X999"));
        } catch (ActuacioNoExisteixException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\n--- Eliminar ---");
        try {
            gestor.eliminarActuacio("C001");
            System.out.println("Actuació amb codi C001 eliminada correctament.");
        } catch (ActuacioNoExisteixException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            gestor.eliminarActuacio("X999");
            System.out.println("Actuació amb codi X999 eliminada correctament.");
        } catch (ActuacioNoExisteixException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\n--- Festivals ---");
        gestor.mostrarSegonsTipus("Festival");

        System.out.println("\n--- Concerts ---");
        gestor.mostrarSegonsTipus("Concert");

        System.out.println("\n--- Tots ---");
        gestor.mostrarSegonsTipus("Tots");

        System.out.println("\n--- Subconjunt > 50€ ordenat per data ---");
        gestor.mostrarCostSuperiorA(50);

        System.out.println("\n--- Guardar dades ---");
        gestor.guardar("actuacions.dat");
        System.out.println("Dades guardades.");

        GestorActuacions gestor2 = new GestorActuacions("MusicCat");

        System.out.println("\n--- Carregar dades en un nou gestor ---");
        gestor2.carregar("actuacions.dat");
        System.out.println("Dades carregades.");

        System.out.println("\n--- Totes després de carregar ---");
        gestor2.mostrarActuacions();
    }

}
