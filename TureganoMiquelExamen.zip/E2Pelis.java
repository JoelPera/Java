public class E2Pelis {
    String titol;
    double Valoracio;
}
