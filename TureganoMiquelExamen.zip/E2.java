public class E2 {
    
    public static double mitjana(E2Pelis pelis []) {
        double acum = 0;
        for (int i = 0; i < pelis.length; i++) {
            acum += pelis[i].Valoracio;
        }
        double mitjana = acum / pelis.length;
        return mitjana;
    }
    public static String pitjorPeli(E2Pelis pelis []){
        String nomPitjorPeli = null ;
        double pitjorValor = 5; // Poso 5 pq les pelis son valorades en 5/5 crec
        for (int i = 0; i < pelis.length; i++) {
            if (pelis[i].Valoracio < pitjorValor) {
                nomPitjorPeli = pelis[i].titol;
            }
        }
        return nomPitjorPeli;
    }
    
    public static void main(String[] args) {
        int numpelis = Utils.nextInt("Quantes pel·lícules vols introduir? ");
        E2Pelis pelis[] = new E2Pelis[numpelis];
        for (int i = 0; i < pelis.length; i++) {
            pelis[i] = new E2Pelis();
            System.out.printf("\n\nPel·licula %d\n", 1 + i);
            pelis[i].titol = Utils.nextString("Títol: ");
            pelis[i].Valoracio = Utils.nextDouble("Valoració: ");
            
        }
        
        int opcio = -1;
        while (opcio != 0) {
            opcio = Utils.nextInt("1. Mitjana\n2. Pitjor pel·licula\n0. Sortir\nOpció: ");
            if (opcio == 1) {
                System.out.printf("Mitjana %.2f\n\n", mitjana(pelis));;
            }else if (opcio == 2) {
                System.out.printf("Pitjor pel·licula: %s\n\n", pitjorPeli(pelis));
            }
        }
    }
}
