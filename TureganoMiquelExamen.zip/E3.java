public class E3 {
    public static double[] llegeixTemperatures() {
        double temperaturesSetmana[] = new double[7];
        for (int i = 0; i < 7; i++) {
            System.out.printf("Dia %d: ", i + 1);
            temperaturesSetmana[i] = Utils.nextDouble("");
        }
        return temperaturesSetmana;
    }

    public static double calcularMitjana(double temperatures[]) {
        double acum = 0;
        for (int i = 0; i < temperatures.length; i++) {
            acum += temperatures[i];
        }
        double mitjana = acum / 7;
        return mitjana;
    }

    public static int obteMaxim(double temperatures[]) {
        double tmepMax = 0;
        int diaMax = 0;
        for (int i = 0; i < temperatures.length; i++) {
            if (temperatures[i] > tmepMax) {
                tmepMax = temperatures[i];
                diaMax = i;
            }
        }
        return diaMax;
    }

    public static int comptaSuperiorsMitjana(double temperatures[]) {
        int acum = 0;
        for (int i = 0; i < temperatures.length; i++) {
            if (temperatures[i] > calcularMitjana(temperatures)) {
                acum++;
            }
        }
        return acum;
    }

    public static void main(String[] args) {
        double temperatures[] = llegeixTemperatures();
        System.out.printf("\nTemperatura mitjana: %.2f\n", calcularMitjana(temperatures));
        System.out.printf("Temperatura màxima: %.1f (dia %d)\n", temperatures[obteMaxim(temperatures)],
                obteMaxim(temperatures) + 1);
        System.out.printf("Nombre de dies per sobre de la mitjana: %d\n", comptaSuperiorsMitjana(temperatures));

    }
}
