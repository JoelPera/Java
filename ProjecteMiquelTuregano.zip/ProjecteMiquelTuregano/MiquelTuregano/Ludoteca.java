package MiquelTuregano;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;
import java.util.Map.Entry;

public class Ludoteca {
    private Map<String, Recurs> recursos = new HashMap<>();

    private Set<Recurs> destacats = new TreeSet<>();

    // Com qui diu la constructora esta feta, ara hem de fer el CRUD començarem amb:
    // CREATE
    public void afegirRecurs(Recurs r) throws Exception {
        if (recursos.containsKey(r.getCodi())) {
            throw new Exception("Error, codi repetit.");
            // Aixo dels exceptions es brutal
        }
        recursos.put(r.getCodi(), r);
    }

    public void afegirVideojoc() throws Exception {
        String codi = Utils.nextString("Introdueix el codi:");
        String titol = Utils.nextString("Introdueix el títol: ");
        int any = Utils.nextInt("Introdueix l'any: ");

        String disponibleString = Utils.nextString("Disponible? (true/false): ");
        boolean disponible = disponibleString.equalsIgnoreCase("true") ? true : false;

        String plataforma = Utils.nextString("Introdueix la plataforma: ");
        int pegi = Utils.nextInt("Introdueix el PEGI: ");
        Videojoc v = new Videojoc(codi, titol, any, disponible, plataforma, pegi);
        afegirRecurs(v);
    }

    public void afegirJocDeTaula() throws Exception {
        String codi = Utils.nextString("Introdueix el codi:");
        String titol = Utils.nextString("Introdueix el títol: ");
        int any = Utils.nextInt("Introdueix l'any: ");

        String disponibleString = Utils.nextString("Disponible? (true/false): ");
        boolean disponible = disponibleString.equalsIgnoreCase("true") ? true : false;

        int minJugadors = Utils.nextInt("Minim de jugadors necessaris? ");
        int maxJugadors = Utils.nextInt("Maxim de jugadors necessaris? ");
        int duracio = Utils.nextInt("Duracio aproximada del joc? ");
        JocTaula j = new JocTaula(codi, titol, any, disponible, minJugadors, maxJugadors, duracio);
        afegirRecurs(j);
    }

    // Primera part de CRUD feta anem amb:
    // READ
    public void mostrarTots() {
        for (Entry<String, Recurs> r : recursos.entrySet()) {
            System.out.println(r.getValue() + "\n\n");
        }

    }

    public Recurs buscarRecurs(String c) throws Exception {
        if (!recursos.containsKey(c)) {
            throw new Exception("Error, no s'ha trobat aquest recurs.");
        }
        return recursos.get(c);
    }

    // Segona part feta, ara
    // UPDATE
    // Inicialment havia fet aquest modificar recurs pero em feia posar
    // introduccions de dades a ludoteca q crec que esta malament, canviaré el
    // modificar
    // pero no el afegir, no se de quina manera es mes correcte, no hem treballat
    // tant
    // el intentar deixar el codi el maxim net, ho sento
    public void modificarRecursUI(String codi) throws Exception {
        Recurs r = buscarRecurs(codi);
        if (r instanceof Videojoc v) {
            v.setTitol(Utils.nextString("Nou titol: "));
            v.setAny(Utils.nextInt("Nou any: "));

            String disponibleString = Utils.nextString("Està disponible actualment? (true/false): ");
            boolean disponible = disponibleString.equalsIgnoreCase("true") ? true : false;
            v.setDisponible(disponible);

            v.setPlataforma(Utils.nextString("Nova plataforma: "));
            v.setPegi(Utils.nextInt("Nou PEGI: "));
        } else if (r instanceof JocTaula j) {
            j.setTitol(Utils.nextString("Nou titol: "));
            j.setAny(Utils.nextInt("Nou any: "));

            String disponibleString = Utils.nextString("Ara està disponible? (true/false): ");
            boolean disponible = disponibleString.equalsIgnoreCase("true") ? true : false;
            j.setDisponible(disponible);

            j.setMinJugadors(Utils.nextInt("Min jugadors: "));
            j.setMaxJugadors(Utils.nextInt("Max jugadors: "));
            j.setDuracio(Utils.nextInt("Duració: "));
        } else {
            throw new Exception("Tipus de recurs desconegut");
        }
    }

    public void modificarRecurs(String codi, Recurs r) throws Exception {
        if (!recursos.containsKey(codi)) {
            throw new Exception("Error, no existeix aquest recurs");
        }
        recursos.put(codi, r);
    }

    // Ultima part ara
    // DELETE
    public void eliminarRecurs(String c) throws Exception {
        if (!recursos.containsKey(c)) {
            throw new Exception("Error, no existeix aquest recurs.");
        }
        recursos.remove(c);
    }

    // CRUD fet de manera crec que impoluta, ara farem els destacats
    // DESTACATS
    public void afegirDestacat(String c) throws Exception {
        Recurs r = buscarRecurs(c);
        if (!destacats.add(r)) {
            throw new Exception("Error, aquest recurs ja hi és a destacats.");
        }
    }

    public void mostrarDestacats() {
        destacats.forEach(System.out::println);
    }
    
    public void eliminarDestacats(String c) throws Exception {
        Recurs r = buscarRecurs(c);
        if (!destacats.contains(r)) {
            throw new Exception("Error, aquest recurs no està a destacats.");
        }
        destacats.remove(r);
    }
    // Ara anem a fer la persistencia, primer guardarem info en fitxers tant destacats com recursos generals
    // GUARDAR
    public void guardarRecursos(String f) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
            oos.writeObject(recursos);
            oos.writeObject(destacats);
        } catch (IOException e) {
            System.out.println("Error en guardar " + e.getMessage());
        }
        // Estem preparant el fitxer f per escriure, creem el oos amb el f i despres amb
        // el
        // writeObject() escribim el que vulguem passar, mes del mateix q a baix,
        // intuitiu
    }
    // CARREGAR
    public void carregarRecursos(String f) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            recursos = (Map<String, Recurs>) ois.readObject();
            destacats = (Set<Recurs>) ois.readObject();
        } catch (IOException e) {
            System.out.println("Error en carregar " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Fitxer no trobat" + e.getMessage());
        }
    }
}
