# LUDOTECA FETA!!
M'ha agradat molt aquest projecte, especialment el tema de serializables i el de les excepcions, les excepcions et salven el cul de moltes coses, ets un gran profe Romà, real q almenys a mi em motives a aprendre, cuidat rei
Miquel