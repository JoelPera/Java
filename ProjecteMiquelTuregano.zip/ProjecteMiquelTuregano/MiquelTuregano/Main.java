package MiquelTuregano;

public class Main {
    private static final String fitxer = "dades.dat";
    // He pensat, si poso un String dades.dat dos cops podria fer una constant ja
    // que el nom no
    // canviarà mai, crec que va bé per buscar codi net ;)

    public static void main(String[] args) {
        Ludoteca ludoteca1 = new Ludoteca();

        int opcio = Utils.nextInt(
                "--- LUDOTECA DIGITAL ---\n1. Afegir videojoc\n2. Afegir joc de taula\n3. Mostrar tots els recursos\n4. Cercar recurs per codi\n5. Modificar recurs\n6. Afegir un recurs a destacats\n7. Eliminar recurs\n8. Mostrar recursos destacats\n9. Guardar dades\n10. Carregar dades\n11. Sortir\n");
        while (opcio != 11) {
            try {
                if (opcio == 1) {
                    ludoteca1.afegirVideojoc();
                    System.out.println("Videojoc afegit correctament.");
                } else if (opcio == 2) {
                    ludoteca1.afegirJocDeTaula();
                    System.out.println("Joc de taula afegit correctament.");
                } else if (opcio == 3) {
                    System.out.println("--- LLISTAT DE RECURSOS ---");
                    ludoteca1.mostrarTots();
                } else if (opcio == 4) {
                    String codi = Utils
                            .nextString("--- CERCA DE RECURSOS ---\nQuin es el codi del recurs que vols buscar? ");
                    System.out.println(ludoteca1.buscarRecurs(codi));
                } else if (opcio == 5) {
                    String codi = Utils.nextString("Introdueix el codi del recurs a modificar: ");

                    Recurs r = ludoteca1.buscarRecurs(codi);
                    Recurs n;
                    if (r instanceof Videojoc) {
                        n = new Videojoc(
                                codi,
                                Utils.nextString("Nou titol: "),
                                Utils.nextInt("Nou any: "),
                                Utils.nextBoolean("Disponible? (true/false): "),
                                Utils.nextString("Nova plataforma: "),
                                Utils.nextInt("Nou PEGI: "));
                    } else {
                        n = new JocTaula(
                                codi,
                                Utils.nextString("Nou titol: "),
                                Utils.nextInt("Nou any: "),
                                Utils.nextBoolean("Disponible? (true/false): "),
                                Utils.nextInt("Min jugadors: "),
                                Utils.nextInt("Max jugadors: "),
                                Utils.nextInt("Duració: "));
                    }
                    ludoteca1.modificarRecurs(codi, n);
                    System.out.println("Recurs modificat correctament.");
                } else if (opcio == 6) {
                    String codi = Utils.nextString("Quin es el codi del recurs que vols afegir a destacats? ");
                    ludoteca1.afegirDestacat(codi);
                    System.out.println("Recurs afegit a destacat correctament.");
                } else if (opcio == 7) {
                    String codi = Utils.nextString("Quin es el codi del recurs que vols eliminar? ");
                    ludoteca1.eliminarRecurs(codi);
                    System.out.println("Recurs eliminat correctament.");
                } else if (opcio == 8) {
                    System.out.println("--- LLISTAT DE RECURSOS DESTACATS ---");
                    ludoteca1.mostrarDestacats();
                } else if (opcio == 9) {
                    ludoteca1.guardarRecursos(fitxer);
                    System.out.println("Recursos guardats a: " + fitxer);
                } else if (opcio == 10) {
                    ludoteca1.carregarRecursos(fitxer);
                    System.out.println("Recursos carregats de: " + fitxer);
                }
                opcio = Utils.nextInt(
                        "--- LUDOTECA DIGITAL ---\n1. Afegir videojoc\n2. Afegir joc de taula\n3. Mostrar tots els recursos\n4. Cercar recurs per codi\n5. Modificar recurs\n6. Afegir un recurs a destacats\n7. Eliminar recurs\n8. Mostrar recursos destacats\n9. Guardar dades\n10. Carregar dades\n11. Sortir\n");

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}