package MiquelTuregano;

import java.io.Serializable;

public class JocTaula extends Recurs implements Serializable {
    private int minJugadors;
    private int maxJugadors;
    private int duracio;
    public JocTaula(String codi, String titol, int any, boolean disponible, int minJugadors, int maxJugadors,
            int duracio) {
        super(codi, titol, any, disponible);
        this.minJugadors = minJugadors;
        this.maxJugadors = maxJugadors;
        this.duracio = duracio;
    }
    public int getMinJugadors() {
        return minJugadors;
    }
    public void setMinJugadors(int minJugadors) {
        this.minJugadors = minJugadors;
    }
    public int getMaxJugadors() {
        return maxJugadors;
    }
    public void setMaxJugadors(int maxJugadors) {
        this.maxJugadors = maxJugadors;
    }
    public int getDuracio() {
        return duracio;
    }
    public void setDuracio(int duracio) {
        this.duracio = duracio;
    }
    
    @Override
    public int calcularTempsUs(){
        return (int) (duracio * 1.2);
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append("\nTipus: Joc de Taula\nJugadors: ")
        .append(minJugadors).append("-").append(maxJugadors)
        .append("\nTemps d'ùs: ").append(calcularTempsUs()).append("minuts");
        return sb.toString();
    }
}
