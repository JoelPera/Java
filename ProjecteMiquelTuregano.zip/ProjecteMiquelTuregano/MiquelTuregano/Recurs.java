package MiquelTuregano;

import java.io.Serializable;


public abstract class Recurs implements Serializable, Comparable<Recurs> {
    protected String codi;
    protected String titol;
    protected int any;
    protected boolean disponible;
    public Recurs(String codi, String titol, int any, boolean disponible) {
        this.codi = codi;
        this.titol = titol;
        this.any = any;
        this.disponible = disponible;
    }
    public String getCodi() {
        return codi;
    }
    public String getTitol() {
        return titol;
    }
    public int getAny() {
        return any;
    }
    public boolean isDisponible() {
        return disponible;
    }
    // No hi ha set codi pq es el identificador de el treeset, i si el canvio podria trencar el treeset
    public void setTitol(String titol) {
        this.titol = titol;
    }
    public void setAny(int any) {
        this.any = any; 
    }
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
    public abstract int calcularTempsUs();

    @Override
    public int compareTo(Recurs r){
        return this.codi.compareTo(r.codi);
    }

    public  String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(codi).append("] ").append(titol).append(" - ").append(any).append(" - ")
        .append(disponible ? " Disponible" : "No disponible");
        return sb.toString();
    }
}
