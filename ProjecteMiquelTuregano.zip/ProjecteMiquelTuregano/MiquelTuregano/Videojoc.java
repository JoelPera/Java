package MiquelTuregano;

import java.io.Serializable;

public class Videojoc extends Recurs implements Serializable {
    private String plataforma;
    private int pegi;
    public Videojoc(String codi, String titol, int any, boolean disponible, String plataforma, int pegi) {
        super(codi, titol, any, disponible);
        this.plataforma = plataforma;
        this.pegi = pegi;
    }
    public String getPlataforma() {
        return plataforma;
    }
    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }
    public int getPegi() {
        return pegi;
    }
    public void setPegi(int pegi) {
        this.pegi = pegi;
    }
    @Override
    public int calcularTempsUs(){
        if (pegi <= 7) {
            return 60;
        }else if (pegi > 7 && pegi < 18) {
            return 90;
        }else{
            return 120;
        }
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append("\nTipus: Videojoc\nPlataforma: ").append(plataforma)
        .append("\nPEGI: ").append(pegi).append("\nTemps d'ùs: ").append(calcularTempsUs()).append("min");
        return sb.toString();
    }
}
