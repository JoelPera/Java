package MiquelTuregano;

public class MainTest {
    public static void main(String[] args) {
        try {
            Ludoteca l = new Ludoteca();
            // MAIN per testing
            // CREATE
            Recurs v1 = new Videojoc("v1", "MewGenics", 2026, true, "PC", 12);
            Recurs j1 = new JocTaula("j2", "Catan", 2014, true, 2, 4, 60);
            l.afegirRecurs(v1);
            l.afegirRecurs(j1);
            System.out.println("CREATE OK");
            // ERROR joc repetit, forçem excepcio
            try {
                Recurs repetit = new Videojoc("v1", "MewGenics", 2026, true, "PC", 12);
                l.afegirRecurs(repetit);
            } catch (Exception e) {
                System.out.println("Excepció esperada, error: " + e.getMessage());
            }
            // READ recurs existent
            System.out.println(l.buscarRecurs("v1"));
            // Tots els recursos
            l.mostrarTots();
            // ERROR recurs no existent
            try {
                l.buscarRecurs("69");
            } catch (Exception e) {
                System.out.println("Excepció esperada, error: " + e.getMessage());
            }
            // UPDATE canvis
            Recurs v1Nou = new Videojoc("v1", "The Binding Of Isaac", 2013, true, "PC", 18);
            l.modificarRecurs("v1", v1Nou);
            System.out.println(l.buscarRecurs("v1")); // RECURS MODIFICAT
            // ERROR recurs no existent un altre cop
            try {
                l.modificarRecurs("69", v1Nou);
            } catch (Exception e) {
                System.out.println("Excepció esperada, error: " + e.getMessage());
            }

            // DESTACATS
            l.afegirDestacat("v1");
            l.mostrarDestacats(); // AFEGIM 1 I MOSTREM

            // ERROR destacat repetit, forçem excepcio
            try {
                l.afegirDestacat("v1");
            } catch (Exception e) {
                System.out.println("Excepció esperada, error: " + e.getMessage());
            }
            // DELETE destacats
            l.eliminarDestacats("v1");
            l.mostrarDestacats(); // Destacat borrat

            // DELETE recurs
            l.eliminarRecurs("j2");
            System.out.println("Eliminat CATAN");
            // ERROR elminar inexistent, forçem excepcio un altre cop
            try {
                l.eliminarRecurs("j2");
            } catch (Exception e) {
                System.out.println("Excepció esperada, error: " + e.getMessage());
            }

            //SERIALITZACIO test final
            l.guardarRecursos("test.dat");
            Ludoteca l2 = new Ludoteca();
            l2.carregarRecursos("test.dat");
            System.out.println("Recursos gaurdats i carregats a l2");
            l2.mostrarTots();
            System.out.println("SERIALITZACIO OK");

            System.out.println("\n\n----------- TEST FINALITZAT, TOT OK-----------");

        } catch (Exception e) {
            System.out.println("ERROR GENERAL: " + e.getMessage());
        }
    }
}
