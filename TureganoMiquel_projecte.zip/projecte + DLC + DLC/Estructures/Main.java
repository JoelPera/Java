package Estructures;

import java.util.Scanner;
import java.util.random.RandomGenerator;

public class Main {

    public static Scanner sc = new Scanner(System.in);
    public static RandomGenerator rg = RandomGenerator.getDefault();

    public static void main(String[] args) {
        // AYOOOO que tal com està el millor profe de tot Carles Vallbona?? nomes dirte
        // que espero que gaudeixis del codi, et puc dir sota jurament que he utilitzat
        // chatgpt 2 cops, per fer un array de noms de vaixells, i per que quan feia els
        // thread.sleep o com es digui em donava error i no sabia que havia de fer el
        // try catch, cosa que realment si que hem aprés ja que el Valera ens va dir que
        // feia, no m'enrollo més, compra't l'arc raiders ;)
        System.out.print("=============================\n      Enfonsar la flota\n=============================\n");
        System.out.print("1. Jugar\n2. Sortir\n=============================\nOpció: ");

        int opcio = Integer.parseInt(sc.nextLine());
        while (opcio != 1 && opcio != 2) {
            System.out.print(
                    "\n\n\n\n========================================\nNo es una opció valida, ha de ser 1 o 2\n========================================\nNova opció: ");
            opcio = Integer.parseInt(sc.nextLine());
        }
        if (opcio == 1) {
            System.out.print(
                    "\n\nVols jugar contra la maquina o vols col·locar tu  els vaixells i que un company t'els enfonsi?\n\n");
            System.out.print("1. Jugar contra la maquina\n2. Col·locar els vaixells tu mateix\nOpció: ");
            int mode_jugador = Integer.parseInt(sc.nextLine());
            while (mode_jugador != 1 && mode_jugador != 2) {
                System.out.println("Escull 1 per jugar contra la maquina o 2 per col·locar els vaixells tu: ");
                mode_jugador = Integer.parseInt(sc.nextLine());
            }
            int mode_joc = 0;
            int files = 0;
            int columnes = 0;
            int[][] taulell = null;
            Vaixell[] vaixells = null;
            int[][] taulellmq = null;
            Vaixell[] vaixellsmq = null;
            System.out.print(
                    "\n\nD'acord, quin mode voldràs jugar?.\n1. Joc amb 1 vaixell\n2. Joc amb 3 vaixells\nMode: ");
            mode_joc = Integer.parseInt(sc.nextLine());
            while (mode_joc != 1 && mode_joc != 2) {
                System.out.printf("%d no es una opció valida, esciriu 1 o 2: ", mode_joc);
                mode_joc = Integer.parseInt(sc.nextLine());
            }
            System.out.print("\nQuantes files voldràs al taulell? ");
            files = Integer.parseInt(sc.nextLine());
            while (files < 6) {
                System.out.print("El minim de files ha de ser de 6, quantes vols? ");
                files = Integer.parseInt(sc.nextLine());
            }
            System.out.print("\nQuantes columnes voldràs al taulell? ");
            columnes = Integer.parseInt(sc.nextLine());
            while (columnes < 8) {
                System.out.print("El minim de columnes són 8, quantes vols? ");
                columnes = Integer.parseInt(sc.nextLine());
            }
            System.out.println("\n\nPerfecte, aquest serà el teu taulell: ");
            taulell = new int[files][columnes];
            taulellmq = new int[files][columnes];
            System.out.print("   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    taulell[i][j] = 0;
                    if (taulell[i][j] == 0) {
                        System.out.printf("%3c", '-');
                    }
                }
                System.out.println();
            }
            // inici de sense if
            int num_vaixells = (mode_joc == 1) ? 1 : 3;
            vaixells = new Vaixell[num_vaixells];
            vaixellsmq = new Vaixell[num_vaixells];
            int aux1 = 0;
            int aux2 = -1;
            int auxiliar1 = 0;
            int auxiliar2 = -1;
            int nom_no_repetit1 = -1;
            int nom_no_repetit2 = -1;
            int nom_no_repetit3 = -1;
            String[] nomsVaixells = { "Black Pearl", "Flying Dutchman", "HMS Victory", "Queen Anne's Revenge",
                    "USS Constitution", "HMS Endeavour", "Jolly Roger", "Santa Maria", "Red Rackham", "Golden Hind",
                    "Interceptor", "Adventure Galley", "HMS Bounty", "Royal Fortune", "Whydah" };
            /*
             * Array de Strings clarament fet per chatgpt, no m'anava a posar a escriure 15
             * noms de vaixells aleatoris, li he dit que digui noms de vaixells famosos i
             * ja.
             */

            for (int i = 0; i < vaixells.length; i++) {
                vaixells[i] = new Vaixell();
                vaixellsmq[i] = new Vaixell();
                boolean mida_correcte = false;
                boolean no_repetida = false;
                System.out.printf("\nQuin serà el nom del vaixell numero %d: ", i + 1);
                vaixells[i].nom = sc.nextLine();
                if (i == 0) {
                    nom_no_repetit1 = rg.nextInt(nomsVaixells.length);
                    vaixellsmq[i].nom = nomsVaixells[nom_no_repetit1];
                } else if (i == 1) {
                    nom_no_repetit2 = rg.nextInt(nomsVaixells.length);
                    while (nom_no_repetit1 == nom_no_repetit2) {
                        nom_no_repetit2 = rg.nextInt(nomsVaixells.length);
                    }
                    vaixellsmq[i].nom = nomsVaixells[nom_no_repetit2];
                } else if (i == 2) {
                    nom_no_repetit3 = rg.nextInt(nomsVaixells.length);
                    while (nom_no_repetit3 == nom_no_repetit1 || nom_no_repetit3 == nom_no_repetit2) {
                        nom_no_repetit3 = rg.nextInt(nomsVaixells.length);
                    }
                    vaixellsmq[i].nom = nomsVaixells[nom_no_repetit3];
                }
                // nom preguntat, ara a preguntar mesura
                System.out.printf("\nDe quina mesura voldràs el vaixell %d: ", i + 1);
                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                vaixellsmq[i].mida = rg.nextInt(2, 5);
                if (vaixells.length == 1) {
                    // comprovacio per 1 vaixell
                    // el random no cal comprovar-lo pq si o si sera de mesura correcte
                    while (vaixells[i].mida < 2 || vaixells[i].mida > 4) {
                        System.out.print("\nLa mesura ha de ser entre 2 i 4: ");
                        vaixells[i].mida = Integer.parseInt(sc.nextLine());
                    }
                } else {
                    // comprovacio per 3 vaixells per humà
                    while (!mida_correcte || !no_repetida) {
                        mida_correcte = false;
                        no_repetida = false;
                        if (vaixells[i].mida <= 4 && vaixells[i].mida >= 2) {
                            mida_correcte = true;
                        } else {
                            System.out.print("\nMesura incorrecte, la mesura ha de ser entre 2, 3 o 4: ");
                            vaixells[i].mida = Integer.parseInt(sc.nextLine());
                        }
                        if (i == 0) {
                            aux1 = vaixells[i].mida;
                            no_repetida = true;
                        } else if (i == 1) {
                            if (vaixells[i].mida != aux1) {
                                no_repetida = true;
                                aux2 = vaixells[i].mida;
                            } else {
                                System.out.print("\nLa mida no es pot repetir, torna-la a introduïr: ");
                                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                            }
                        } else if (i == 2) {
                            if (vaixells[i].mida != aux1 && vaixells[i].mida != aux2) {
                                no_repetida = true;
                            } else {
                                System.out.print("\nLa mida no es pot repetir, torna-la a introduïr: ");
                                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                            }
                        }
                    }
                    if (i == 0) {
                        auxiliar1 = vaixellsmq[i].mida;
                    } else if (i == 1) {
                        while (vaixellsmq[i].mida == auxiliar1) {
                            vaixellsmq[i].mida = rg.nextInt(2, 5);
                        }
                        auxiliar2 = vaixellsmq[i].mida;
                    } else if (i == 2) {
                        while (vaixellsmq[i].mida == auxiliar1 || vaixellsmq[i].mida == auxiliar2) {
                            vaixellsmq[i].mida = rg.nextInt(2, 5);
                        }
                    }
                }
                System.out.print("\nEn quina posició voldràs el vaixell, vertical (v) o horitzontal (h)? ");
                vaixells[i].orientacio = Character.toLowerCase(sc.nextLine().charAt(0));
                while (vaixells[i].orientacio != 'v' && vaixells[i].orientacio != 'h') {
                    System.out.print("\nCaracter no permès.\n Has d'escriure v per vertical o h per horitzontal: ");
                    vaixells[i].orientacio = Character.toLowerCase(sc.nextLine().charAt(0));
                }
                if (rg.nextInt(2) == 1) {
                    vaixellsmq[i].orientacio = 'v';
                } else {
                    vaixellsmq[i].orientacio = 'h';
                }

                System.out.printf("\nQuina serà la fila inicial pel vaixell numero %d? ", i + 1);
                vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                System.out.printf("\nQuina serà la columna inicial pel vaixell numero %d? ", i + 1);
                vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                // inici de comprovacions
                boolean quep = false;
                boolean no_es_sobreposa = false;
                while (!quep || !no_es_sobreposa) {
                    quep = true;
                    no_es_sobreposa = true;

                    if (vaixells[i].orientacio == 'v') {
                        if (vaixells[i].fila_inicial + vaixells[i].mida > files) {
                            quep = false; // no hi cap
                        }
                        if (quep) {
                            for (int j = 0; j < vaixells[i].mida; j++) {
                                if (taulell[vaixells[i].fila_inicial + j][vaixells[i].columna_inicial] != 0) {
                                    no_es_sobreposa = false; // xoca amb un altre vaixell
                                }
                            }
                        }
                    } else if (vaixells[i].orientacio == 'h') {
                        if (vaixells[i].columna_inicial + vaixells[i].mida > columnes) {
                            quep = false; // no hi cap
                        }
                        if (quep) {
                            for (int j = 0; j < vaixells[i].mida; j++) {
                                if (taulell[vaixells[i].fila_inicial][vaixells[i].columna_inicial + j] != 0) {
                                    no_es_sobreposa = false; // xoca amb un altre vaixell
                                }
                            }
                        }
                    }

                    if (!quep || !no_es_sobreposa) {
                        System.out.print(
                                "\nLa posició del vaixell no es apte, torna a introduïr la fila i columna inicials\nFila inicial: ");
                        vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                        System.out.print("Ara introdueix la nova columna: ");
                        vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                    }
                }
                // Comprovació de si es sobreposa el vaixell de la maquina
                if (vaixellsmq[i].orientacio == 'v') {
                    vaixellsmq[i].fila_inicial = rg.nextInt(files - vaixellsmq[i].mida + 1);
                    vaixellsmq[i].columna_inicial = rg.nextInt(columnes);
                } else {
                    vaixellsmq[i].fila_inicial = rg.nextInt(files);
                    vaixellsmq[i].columna_inicial = rg.nextInt(columnes - vaixellsmq[i].mida + 1);
                }
                no_es_sobreposa = false;
                while (!no_es_sobreposa) {
                    no_es_sobreposa = true;
                    if (vaixellsmq[i].orientacio == 'v') {
                        // es sobreposa
                        for (int j = 0; j < vaixellsmq[i].mida; j++) {
                            if (taulellmq[vaixellsmq[i].fila_inicial + j][vaixellsmq[i].columna_inicial] != 0) {
                                no_es_sobreposa = false;
                            }
                        }
                    } else if (vaixellsmq[i].orientacio == 'h') {

                        // es sobreposa
                        for (int j = 0; j < vaixellsmq[i].mida; j++) {
                            if (taulellmq[vaixellsmq[i].fila_inicial][vaixellsmq[i].columna_inicial + j] != 0) {
                                no_es_sobreposa = false;
                            }
                        }
                    }
                    if (!no_es_sobreposa) {
                        if (vaixellsmq[i].orientacio == 'v') {
                            vaixellsmq[i].fila_inicial = rg.nextInt(files - vaixellsmq[i].mida + 1);
                            vaixellsmq[i].columna_inicial = rg.nextInt(columnes);
                        } else {
                            vaixellsmq[i].fila_inicial = rg.nextInt(files);
                            vaixellsmq[i].columna_inicial = rg.nextInt(columnes - vaixellsmq[i].mida + 1);
                        }
                    }
                }
                for (int j = 0; j < vaixells[i].mida; j++) {
                    if (vaixells[i].orientacio == 'v') {
                        taulell[vaixells[i].fila_inicial + j][vaixells[i].columna_inicial] = i + 1;
                    } else if (vaixells[i].orientacio == 'h') {
                        taulell[vaixells[i].fila_inicial][vaixells[i].columna_inicial + j] = i + 1;
                    }
                }
                for (int j = 0; j < vaixellsmq[i].mida; j++) {
                    if (vaixellsmq[i].orientacio == 'v') {
                        taulellmq[vaixellsmq[i].fila_inicial + j][vaixellsmq[i].columna_inicial] = i + 1;
                    } else if (vaixellsmq[i].orientacio == 'h') {
                        taulellmq[vaixellsmq[i].fila_inicial][vaixellsmq[i].columna_inicial + j] = i + 1;
                    }
                }
                if (i != vaixells.length - 1) {

                    System.out.print("\n\n\nVaixell col·locat correctament!\n   ");
                    for (int j = 0; j < columnes; j++) {
                        System.out.printf("%3d", j + 1);
                    }
                    System.out.println();
                    for (int j = 0; j < taulell.length; j++) {
                        for (int k = 0; k < taulell[j].length; k++) {
                            if (k == 0) {
                                System.out.printf("%3d", j + 1);
                            }
                            if (taulell[j][k] == 0) {
                                System.out.printf("%3c", '-');
                            } else if (taulell[j][k] > 0) {
                                System.out.printf("%3c", '#');
                            }
                        }
                        System.out.println();
                    }
                }
            }
            // PRINT comprovacio
            System.out.println("==============TAULELL FINAL AMB VAIXELLS==============");
            System.out.print("   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    if (taulell[i][j] == 0) {
                        System.out.printf("%3c", '-');
                    } else if (taulell[i][j] > 0) {
                        System.out.printf("%3c", '#');
                    }
                }
                System.out.println();
            }
            for (int i = 5; i > 0; i--) {
                System.out.printf("El joc començarà en %d.\n", i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

            }
            System.out.print("Iniciant el joc en 1");
            // PRINT fet
            // inici joc real
            if (mode_jugador == 2) {
                System.out.print("\n".repeat(30));
            } else {
                System.out.print("\n".repeat(3));
            }
            // print del taulell sense vaixells
            int bombes = 0;
            int bombesmq = 0;
            System.out.print("Anem a jugar!!\n\nPrimerament, quin és el teu nom valerós jugador? ");
            String nomjugador = sc.nextLine();
            System.out.print("\nQuin nom més maco!\n");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.print("Aquí tens el taulell on atacaràs:\n\n   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    System.out.printf("%3c", '-');
                }
                System.out.println();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            int vaixells_vius = mode_joc == 2 ? 3 : 1;
            if (mode_jugador == 1) { // MODE CONTRA LA MAQUINA

                System.out.printf("Començaràs atacant tu %s, on voldràs llençar la primera bomba?? \n", nomjugador);
                int vaixells_vius_maquina = vaixells_vius;
                int[] fila_feta_servir = new int[files * columnes];
                int[] columna_feta_servir = new int[files * columnes];
                int index_intents_maquina = 0;
                while (vaixells_vius != 0 && vaixells_vius_maquina != 0) {
                    // Aqui comença el torn del jugador
                    System.out.print("Introdueix la fila a atacar:");
                    int fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                    System.out.print("Introdueix la columna a atacar:");
                    int columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                    while (fila_atac < 0 || fila_atac >= files || columna_atac < 0 || columna_atac >= columnes) {
                        System.out.print("Aquesta posició està fora de limits.\nTorna a introduïr la fila:");
                        fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                        System.out.print("I ara torna a introduïr la columna:");
                        columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                    } // comprovació fora limits
                    if (taulellmq[fila_atac][columna_atac] == 0) { // Aigua + print
                        System.out.println("\nAigua!!\n");
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulellmq.length; i++) {
                            for (int j = 0; j < taulellmq[i].length; j++) {
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (i == fila_atac && j == columna_atac) {
                                    System.out.printf("%3c", 'O');
                                } else if (taulellmq[i][j] >= 0) {
                                    System.out.printf("%3c", '-');
                                } else if (taulellmq[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                }
                                // Que l'aigua no quedi marcada està fet a proposit, si no facilitaria massa les
                                // coses i així s'entrena més la memoria
                            }
                            System.out.println();
                        }
                    } else if (taulellmq[fila_atac][columna_atac] < 0) { // vaixell que ja te un hit
                        System.out.print("Ja havies donat anteriorment a aquest vaixell!\n");
                    } else if (taulellmq[fila_atac][columna_atac] > 0) {
                        int index = taulellmq[fila_atac][columna_atac];
                        taulellmq[fila_atac][columna_atac] = -taulellmq[fila_atac][columna_atac];

                        boolean enfonsat = true;
                        Vaixell vaixell = vaixellsmq[index - 1];

                        for (int i = 0; i < vaixell.mida; i++) {
                            if (vaixell.orientacio == 'v') {
                                if (taulellmq[vaixell.fila_inicial + i][vaixell.columna_inicial] > 0) {
                                    enfonsat = false;
                                }
                            } else if (vaixell.orientacio == 'h') {
                                if (taulellmq[vaixell.fila_inicial][vaixell.columna_inicial + i] > 0) {
                                    enfonsat = false;
                                }
                            }
                        } // comprovació d'enfonsament de vaixell
                        if (enfonsat) {
                            System.out.printf("%s ha estat tocada i enfonsada!\n", vaixell.nom);
                            vaixells_vius--; // si tocada o enfonsat
                        } else {
                            System.out.printf("%s ha estat tocada!\n", vaixell.nom);
                        }
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulellmq.length; i++) {
                            for (int j = 0; j < taulellmq[i].length; j++) {// print mostrant el hit
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (taulellmq[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                } else {
                                    System.out.printf("%3c", '-');
                                }
                            }
                            System.out.println();
                        }
                    }
                    bombes++; // suma de intents
                    if (vaixells_vius_maquina == 0) {
                        break;
                    }

                    // inici del torn de la maquina
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    boolean repetit = true;
                    while (repetit) {
                        repetit = false;
                        fila_atac = rg.nextInt(files);
                        columna_atac = rg.nextInt(columnes);
                        for (int i = 0; i < index_intents_maquina; i++) {
                            if (fila_feta_servir[i] == fila_atac && columna_feta_servir[i] == columna_atac) {
                                repetit = true;
                                break;
                            }
                        }
                    }
                    fila_feta_servir[index_intents_maquina] = fila_atac;
                    columna_feta_servir[index_intents_maquina] = columna_atac;
                    index_intents_maquina++;
                    System.out.printf("Ara es el torn de la maquina!!\n Atacarà a la fila %d i la columna %d\n",
                            fila_atac + 1, columna_atac + 1);
                    String punts = "";
                    for (int i = 0; i < 4; i++) {
                        System.out.printf("%s\n", punts);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                        punts += '.';
                    }
                    if (taulell[fila_atac][columna_atac] == 0) { // Aigua + print
                        System.out.println("\nAigua!!\n");
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulell.length; i++) {
                            for (int j = 0; j < taulell[i].length; j++) {
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (i == fila_atac && j == columna_atac) {
                                    System.out.printf("%3c", 'O');
                                } else if (taulell[i][j] >= 0) {
                                    System.out.printf("%3c", '-');
                                } else if (taulell[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                } // teoricament puc copiar els ifs canviant unicament els taulells, aixi puc
                                  // reutilitzar variables

                            }
                            System.out.println();
                        }
                    } else if (taulell[fila_atac][columna_atac] > 0) {
                        int index = taulell[fila_atac][columna_atac];
                        taulell[fila_atac][columna_atac] = -taulell[fila_atac][columna_atac];

                        boolean enfonsat = true;
                        Vaixell vaixell = vaixells[index - 1];

                        for (int i = 0; i < vaixell.mida; i++) {
                            if (vaixell.orientacio == 'v') {
                                if (taulell[vaixell.fila_inicial + i][vaixell.columna_inicial] > 0) {
                                    enfonsat = false;
                                }
                            } else if (vaixell.orientacio == 'h') {
                                if (taulell[vaixell.fila_inicial][vaixell.columna_inicial + i] > 0) {
                                    enfonsat = false;
                                }
                            }
                        } // comprovació d'enfonsament de vaixell
                        if (enfonsat) {
                            System.out.printf("%s ha estat tocada i enfonsada!\n", vaixell.nom);
                            vaixells_vius_maquina--; // si tocada o enfonsat
                        } else {
                            System.out.printf("%s ha estat tocada!\n", vaixell.nom);
                        }
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulell.length; i++) {
                            for (int j = 0; j < taulell[i].length; j++) {// print mostrant el hit
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (taulell[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                } else {
                                    System.out.printf("%3c", '-');
                                }
                            }
                            System.out.println();
                        }
                    }
                    bombesmq++;
                }
                // fi torn maquina
                System.out.print("\n=============================================================================\n");
                if (vaixells_vius == 0) {
                    System.out.printf(
                            "\nLa maquina ha guanyat!! Cada cop estem més aprop de que ARC RAIDERS sigui realitat!!\nHo ha fet en %d intents.\n",
                            bombesmq);
                } else if (vaixells_vius_maquina == 0) {
                    System.out.printf(
                            "\nL'indomable i imparable esperit humà torna a demostrar les grans capacitats de la nostre especie\n%s, definitivament ets el personatge principal, has guanyat als clankers amb només %d intents!!\n",
                            nomjugador, bombes);
                }
                System.out.print("\n=============================================================================\n");
            } else if (mode_jugador == 2) {
                System.out.print("On llançaràs la primera bomba??");
                while (vaixells_vius != 0) {
                    System.out.print("\nIntrodueix la fila a atacar:");
                    int fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                    System.out.print("\nIntrodueix la columna a atacar:");
                    int columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                    while (fila_atac < 0 || fila_atac >= files || columna_atac < 0 || columna_atac >= columnes) {
                        System.out.print("Aquesta posició està fora de limits.\nTorna a introduïr la fila:");
                        fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                        System.out.print("I ara torna a introduïr la columna:");
                        columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                    }
                    if (taulell[fila_atac][columna_atac] == 0) {
                        System.out.println("\nAigua!!\n");
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulell.length; i++) {
                            for (int j = 0; j < taulell[i].length; j++) {
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (i == fila_atac && j == columna_atac) {
                                    System.out.printf("%3c", 'O');
                                } else if (taulell[i][j] >= 0) {
                                    System.out.printf("%3c", '-');
                                } else if (taulell[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                }
                                // Que l'aigua no quedi marcada està fet a proposit, si no facilitaria massa les
                                // coses i així s'entrena més la memoria
                            }
                            System.out.println();
                        }
                    } else if (taulell[fila_atac][columna_atac] < 0) {
                        System.out.print("Ja havies donat anteriorment a aquest vaixell!\n");
                    } else if (taulell[fila_atac][columna_atac] > 0) {
                        int index = taulell[fila_atac][columna_atac];
                        taulell[fila_atac][columna_atac] = -taulell[fila_atac][columna_atac];

                        boolean enfonsat = true;
                        Vaixell vaixell = vaixells[index - 1];

                        for (int i = 0; i < vaixell.mida; i++) {
                            if (vaixell.orientacio == 'v') {
                                if (taulell[vaixell.fila_inicial + i][vaixell.columna_inicial] > 0) {
                                    enfonsat = false;
                                }
                            } else if (vaixell.orientacio == 'h') {
                                if (taulell[vaixell.fila_inicial][vaixell.columna_inicial + i] > 0) {
                                    enfonsat = false;
                                }
                            }
                        }
                        if (enfonsat) {
                            System.out.printf("%s ha estat tocada i enfonsada!\n", vaixell.nom);
                            vaixells_vius--;
                        } else {
                            System.out.printf("%s ha estat tocada!\n", vaixell.nom);
                        }
                        System.out.print("   ");
                        for (int i = 0; i < columnes; i++) {
                            System.out.printf("%3d", i + 1);
                        }
                        System.out.println();
                        for (int i = 0; i < taulell.length; i++) {
                            for (int j = 0; j < taulell[i].length; j++) {
                                if (j == 0) {
                                    System.out.printf("%3d", i + 1);
                                }
                                if (taulell[i][j] < 0) {
                                    System.out.printf("%3c", 'X');
                                } else {
                                    System.out.printf("%3c", '-');
                                }
                            }
                            System.out.println();
                        }
                    }
                    bombes++;
                }
                System.out.print("\n=============================================================================\n");
                System.out.printf(
                        "Enhorabona %s!!\nTots els vaixells han sigut enfonsats amb unicament %d intents!",
                        nomjugador, bombes);
                System.out.print("\n=============================================================================\n");
            }
        } else if (opcio == 2) {
            System.out.println("Has decidit no jugar, porfa prova-ho almenys :(");

        }
    }
}