Hola Romà, com va tot? Espero que bé.
Aqui et presento "projecte" on hi ha el projecte original si no m'equivoco igual que es va demanar i "projecte + DLC + DLC", aqui he ficat un mode per jugar contra una maquina a part de el mode original, es diu DLC per que inicialment era tu contra un taulell on els vaixells estaven posats aleatoriament pero he acabat fent un 1vs1 totalment en condicions.
Poc més, si hi ha alguna consulta:
Gmail personal: miquelapple57@gmail.com
Instagram: soc_el_miquel
Discord: miquelodeon_47 (#4789)
Numero de Seguretat Social: 08 39245820 4 (Obviament inventat)
