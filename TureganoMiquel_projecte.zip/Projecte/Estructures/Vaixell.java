package Estructures;

public class Vaixell {
    public String nom;
    public int mida;
    public int fila_inicial;
    public int columna_inicial;
    public char orientacio;
}