package Estructures;

import java.util.Scanner;

public class Main {

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // AYO ROMÀÀÀÀ, aquest es el projecte real, nomes et demano que el primer cop
        // que provis el projecte + dlc no llegeixis el codi i intenta guanyar.
        System.out.print("=============================\n      Enfonsar la flota\n=============================\n");
        System.out.print("1. Jugar\n2. Sortir\n=============================\nOpció: ");

        int opcio = Integer.parseInt(sc.nextLine());
        while (opcio != 1 && opcio != 2) {
            System.out.print(
                    "\n\n\n\n========================================\nNo es una opció valida, ha de ser 1 o 2\n========================================\nNova opció: ");
            opcio = Integer.parseInt(sc.nextLine());
        }
        if (opcio == 1) {
            System.out.print("\n\n\nPerfecte!! anem a jugar.\n1. Joc amb 1 vaixell\n2. Joc amb 3 vaixells\nMode: ");
            int mode_joc = Integer.parseInt(sc.nextLine());
            while (mode_joc != 1 && mode_joc != 2) {
                System.out.printf("%d no es una opció valida, esciriu 1 o 2: ", mode_joc);
                mode_joc = Integer.parseInt(sc.nextLine());
            }
            System.out.print("\n\n\nQuantes files voldràs al taulell? ");
            int files = Integer.parseInt(sc.nextLine());
            while (files < 6) {
                System.out.print("El minim de files ha de ser de 6, quantes vols? ");
                files = Integer.parseInt(sc.nextLine());
            }
            System.out.print("\n\nQuantes columnes voldràs al taulell? ");
            int columnes = Integer.parseInt(sc.nextLine());
            while (columnes < 8) {
                System.out.print("El minim de columnes són 8, quantes vols? ");
                columnes = Integer.parseInt(sc.nextLine());
            }
            System.out.println("Perfecte, aquest serà el teu taulell: ");
            int taulell[][] = new int[files][columnes];
            System.out.print("   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    taulell[i][j] = 0;
                    if (taulell[i][j] == 0) {
                        System.out.printf("%3c", '-');
                    }
                }
                System.out.println();
            }
            // inici de sense if
            int num_vaixells = (mode_joc == 1) ? 1 : 3;
            Vaixell vaixells[] = new Vaixell[num_vaixells];
            int aux1 = 0;
            int aux2 = -1;
            for (int i = 0; i < vaixells.length; i++) {
                vaixells[i] = new Vaixell();
                boolean mida_correcte = false;
                boolean no_repetida = false;
                System.out.printf("\nDigues el nom del vaixell numero %d: ", i + 1);
                vaixells[i].nom = sc.nextLine();
                // nom preguntat, ara a preguntar mesura
                System.out.printf("\nDe quina mesura voldràs el vaixell %d: ", i + 1);
                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                if (vaixells.length == 1) {
                    // comprovacio per 1 vaixell
                    while (vaixells[i].mida < 2 || vaixells[i].mida > 4) {
                        System.out.print("\nLa mesura ha de ser entre 2 i 4: ");
                        vaixells[i].mida = Integer.parseInt(sc.nextLine());
                    }
                } else {
                    // comprovacio per 3 vaixells
                    while (!mida_correcte || !no_repetida) {
                        mida_correcte = false;
                        no_repetida = false;
                        if (vaixells[i].mida <= 4 && vaixells[i].mida >= 2) {
                            mida_correcte = true;
                        } else {
                            System.out.print("\nMesura incorrecte, la mesura ha de ser entre 2, 3 o 4: ");
                            vaixells[i].mida = Integer.parseInt(sc.nextLine());
                        }
                        if (i == 0) {
                            aux1 = vaixells[i].mida;
                            no_repetida = true;
                        } else if (i == 1) {
                            if (vaixells[i].mida != aux1) {
                                no_repetida = true;
                                aux2 = vaixells[i].mida;
                            } else {
                                System.out.print("\nLa mida no es pot repetir, torna-la a introduïr: ");
                                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                            }
                        } else if (i == 2) {
                            if (vaixells[i].mida != aux1 && vaixells[i].mida != aux2) {
                                no_repetida = true;
                            } else {
                                System.out.print("\nLa mida no es pot repetir, torna-la a introduïr: ");
                                vaixells[i].mida = Integer.parseInt(sc.nextLine());
                            }
                        }
                    }
                }
                System.out.print("\nEn quina posició voldràs el vaixell, vertical (v) o horitzontal (h)? ");
                vaixells[i].orientacio = Character.toLowerCase(sc.nextLine().charAt(0));
                while (vaixells[i].orientacio != 'v' && vaixells[i].orientacio != 'h') {
                    System.out.print("\nCaracter no permès.\n Has d'escriure v per vertical o h per horitzontal: ");
                    vaixells[i].orientacio = Character.toLowerCase(sc.nextLine().charAt(0));
                }

                System.out.printf("\nQuina serà la fila inicial pel vaixell numero %d? ", i + 1);
                vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                while (vaixells[i].fila_inicial < 0 || vaixells[i].fila_inicial >= files) {
                    System.out.printf("\nLa fila ha de ser entre 1 i %d", files);
                    vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                }
                System.out.printf("\nQuina serà la columna inicial pel vaixell numero %d? ", i + 1);
                vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                while (vaixells[i].columna_inicial < 0 || vaixells[i].columna_inicial >= columnes) {
                    System.out.printf("\nLa columna ha de ser entre 1 i %d", columnes);
                    vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                }
                // inici de comprovacions
                boolean quep = false;
                boolean no_es_sobreposa = false;
                while (!quep || !no_es_sobreposa) {
                    quep = true;
                    no_es_sobreposa = true;
                    if (vaixells[i].orientacio == 'v') {
                        // Hi quep
                        if (vaixells[i].fila_inicial + vaixells[i].mida > files) {
                            quep = false;
                        }
                        // es sobreposa
                        for (int j = 0; j < vaixells[i].mida; j++) {
                            if (taulell[vaixells[i].fila_inicial + j][vaixells[i].columna_inicial] != 0) {
                                no_es_sobreposa = false;
                            }
                        }
                        if (!no_es_sobreposa || !quep) {
                            System.out.print(
                                    "\nLa posició del vaixell no es apte, torna a introduïr la fila i columna inicials\nFila inicial: ");
                            vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                            System.out.print("\nAra introdueix la nova columna: ");
                            vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                        }
                    } else if (vaixells[i].orientacio == 'h') {
                        if (vaixells[i].columna_inicial + vaixells[i].mida > columnes) {
                            quep = false;
                        }
                        // es sobreposa
                        for (int j = 0; j < vaixells[i].mida; j++) {
                            if (taulell[vaixells[i].fila_inicial][vaixells[i].columna_inicial + j] != 0) {
                                no_es_sobreposa = false;
                            }
                        }
                        if (!no_es_sobreposa || !quep) {
                            System.out.print(
                                    "\nLa posició del vaixell no es apte, torna a introduïr la fila i columna inicials\nFila inicial: ");
                            vaixells[i].fila_inicial = Integer.parseInt(sc.nextLine()) - 1;
                            System.out.print("\nAra introdueix la nova columna: ");
                            vaixells[i].columna_inicial = Integer.parseInt(sc.nextLine()) - 1;
                        }
                    }
                }
                for (int j = 0; j < vaixells[i].mida; j++) {
                    if (vaixells[i].orientacio == 'v') {
                        taulell[vaixells[i].fila_inicial + j][vaixells[i].columna_inicial] = i + 1;
                    } else if (vaixells[i].orientacio == 'h') {
                        taulell[vaixells[i].fila_inicial][vaixells[i].columna_inicial + j] = i + 1;
                    }
                }
                System.out.println("Vaixell col·locat correctament!\n");
            }
            // PRINT comprovacio
            System.out.println("==============TAULELL FINAL AMB VAIXELLS==============");
            System.out.print("   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    if (taulell[i][j] == 0) {
                        System.out.printf("%3c", '-');
                    } else if (taulell[i][j] > 0) {
                        System.out.printf("%3c", '#');
                    }
                }
                System.out.println();
            }
            // PRINT fet
            // inici joc real
            System.out.print("\n".repeat(30));
            // print del taulell sense vaixells
            int bombes = 0;
            System.out.print("Anem a jugar!!\n\nPrimerament quin és el teu nom jugador: ");
            String nomjugador = sc.nextLine();
            System.out.print("\nQuin nom més maco!\nAquí tens el taulell on atacaràs:\n\n");
            System.out.print("   ");
            for (int i = 0; i < columnes; i++) {
                System.out.printf("%3d", i + 1);
            }
            System.out.println();
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (j == 0) {
                        System.out.printf("%3d", i + 1);
                    }
                    System.out.printf("%3c", '-');
                }
                System.out.println();
            }
            System.out.print("Quina serà la fila i columna de la primera bomba?\n");
            int vaixells_vius = mode_joc == 2 ? 3 : 1;
            while (vaixells_vius != 0) {
                System.out.print("Introdueix la fila a atacar:");
                int fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                System.out.print("Introdueix la columna a atacar:");
                int columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                while (fila_atac < 0 || fila_atac >= files || columna_atac < 0 || columna_atac >= columnes) {
                    System.out.print("Aquesta posició està fora de limits.\nTorna a introduïr la fila:");
                    fila_atac = Integer.parseInt(sc.nextLine()) - 1;
                    System.out.print("I ara torna a introduïr la columna:");
                    columna_atac = Integer.parseInt(sc.nextLine()) - 1;
                }
                if (taulell[fila_atac][columna_atac] == 0) {
                    System.out.println("\nAigua!!\n");
                    System.out.print("   ");
                    for (int i = 0; i < columnes; i++) {
                        System.out.printf("%3d", i + 1);
                    }
                    System.out.println();
                    for (int i = 0; i < taulell.length; i++) {
                        for (int j = 0; j < taulell[i].length; j++) {
                            if (j == 0) {
                                System.out.printf("%3d", i + 1);
                            }
                            if (i == fila_atac && j == columna_atac) {
                                System.out.printf("%3c", 'O');
                            } else if (taulell[i][j] >= 0) {
                                System.out.printf("%3c", '-');
                            } else if (taulell[i][j] < 0) {
                                System.out.printf("%3c", 'X');
                            }
                            // Que l'aigua no quedi marcada està fet a proposit, si no facilitaria massa les
                            // coses i així s'entrena més la memoria
                        }
                        System.out.println();
                    }
                } else if (taulell[fila_atac][columna_atac] < 0) {
                    System.out.print("Ja havies donat anteriorment a aquest vaixell!\n");
                } else if (taulell[fila_atac][columna_atac] > 0) {
                    int index = taulell[fila_atac][columna_atac];
                    taulell[fila_atac][columna_atac] = -taulell[fila_atac][columna_atac];

                    boolean enfonsat = true;
                    Vaixell vaixell = vaixells[index - 1];

                    for (int i = 0; i < vaixell.mida; i++) {
                        if (vaixell.orientacio == 'v') {
                            if (taulell[vaixell.fila_inicial + i][vaixell.columna_inicial] > 0) {
                                enfonsat = false;
                            }
                        } else if (vaixell.orientacio == 'h') {
                            if (taulell[vaixell.fila_inicial][vaixell.columna_inicial + i] > 0) {
                                enfonsat = false;
                            }
                        }
                    }
                    if (enfonsat) {
                        System.out.printf("%s ha estat tocada i enfonsada!\n", vaixell.nom);
                        vaixells_vius--;
                    } else {
                        System.out.printf("%s ha estat tocada!\n", vaixell.nom);
                    }
                    System.out.print("   ");
                    for (int i = 0; i < columnes; i++) {
                        System.out.printf("%3d", i + 1);
                    }
                    System.out.println();
                    for (int i = 0; i < taulell.length; i++) {
                        for (int j = 0; j < taulell[i].length; j++) {
                            if (j == 0) {
                                System.out.printf("%3d", i + 1);
                            }
                            if (taulell[i][j] < 0) {
                                System.out.printf("%3c", 'X');
                            } else {
                                System.out.printf("%3c", '-');
                            }
                        }
                        System.out.println();
                    }
                }
                bombes++;
            }
            System.out.print("\n=============================================================================\n");
            System.out.printf(
                    "Enhorabona %s!!\nTots els vaixells han sigut enfonsats amb un total de %d bombes fetes servir.",
                    nomjugador, bombes);
            System.out.print("\n=============================================================================\n");
        } else if (opcio == 2) {
            System.out.println("Has decidit no jugar.");
        }
    }
}