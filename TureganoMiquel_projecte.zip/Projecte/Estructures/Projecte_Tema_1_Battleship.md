# Projecte Tema 1 - Battleship

### Objectiu general

Desenvolupar una versió simplificada del joc **Battleship** utilitzant
arrays bidimensionals. El programa ha de permetre crear un tauler, col·locar un o diversos vaixells i realitzar
tirades fins a enfonsar-los.

## 1. Menú inicial i selecció del mode

En iniciar el programa s'ha de mostrar un menú:

    1. Jugar
    2. Sortir

Si l'usuari tria **Jugar**, el programa ha de demanar quin mode vol
utilitzar:
    
    1. Joc amb 1 vaixell
    2. Joc amb 3 vaixells

-   En mode **1 vaixell**, es treballarà amb un sol vaixell.
-   En mode **3 vaixells**, l'usuari col·locarà tres vaixells, cadascun
    amb una mida diferent.



## 2. Creació del tauler i col·locació dels vaixells

### 2.1 Creació del tauler

El programa ha de demanar la mida del tauler: 
- **Files mínimes:** 6
- **Columnes mínimes:** 8

Seguidament, s'ha de mostrar el tauler buit.

El tauler s’ha de mostrar amb números de files i columnes per facilitar la introducció de coordenades.

## 2.2 Inserció dels vaixells

Per cada vaixell que s'hagi de col·locar (1 o 3 segons el mode triat),
el programa preguntarà:

1.  **Nom del vaixell**
2.  **Mida del vaixell** (entre 2 i 4)
3.  **Orientació** (`h` = horitzontal, `v` = vertical)
4.  **Fila i columna inicials**

El programa ha de comprovar:
 - Que el vaixell cap dins del tauler.
 - Que no se sobreposa amb cap altre vaixell ja col·locat.

Si la posició és incorrecta mostrar error i tornar a demanar les
dades.

Quan el vaixell es col·loca correctament, s'ha de marcar internament al
tauler.

Un cop inserit tots els vaixells, s'ha de mostrar el taulell de com ha quedat

```
     1  2  3  4  5  6  7  8  9 10
  1  -  -  -  -  -  -  -  -  -  -
  2  -  #  -  -  -  -  -  -  -  -
  3  -  #  -  -  -  -  -  -  -  -
  4  -  #  -  -  -  -  -  -  -  -
  5  -  -  -  #  #  #  #  -  -  -
  6  -  -  -  -  -  -  -  -  -  -
  7  -  -  -  -  -  -  -  -  #  -
  8  -  -  -  -  -  -  -  -  #  -
  9  -  -  -  -  -  -  -  -  -  -
 10  -  -  -  -  -  -  -  -  -  -

```

# 3. Fase de joc: tirades i resultats

Es mostrarà un **tauler buit per al jugador que ataca**, on només es
veuran les tirades fetes.

Cada torn, el jugador introduirà una posició (fila i columna):

-   Si hi ha vaixell ha de mostrar **"tocat"** i quedar marcat amb una **X** en el taulell

```
Tocat!

     1  2  3  4  5  6  7  8  9 10
  1  -  -  -  -  -  -  -  -  -  -
  2  -  -  -  -  -  -  -  -  -  -
  3  -  -  -  -  -  -  -  -  -  -
  4  -  -  -  -  -  -  -  -  -  -
  5  -  -  -  -  X  -  -  -  -  -
  6  -  -  -  -  -  -  -  -  -  -
  7  -  -  -  -  -  -  -  -  -  -
  8  -  -  -  -  -  -  -  -  -  -
  9  -  -  -  -  -  -  -  -  -  -
 10  -  -  -  -  -  -  -  -  -  -
 
 ```

# 4. Enfonsament i finalització de la partida

Un vaixell s'ha de considerar **enfonsat** quan totes les seves
posicions hagin estat tocades.

En mode:
 - **1 vaixell** la partida acaba quan l'únic vaixell queda enfonsat.
 - **3 vaixells** la partida acaba quan **tots tres** estiguin enfonsats.

Quan s'enfonsa:
 - Mostrar: **"Vaixell enfonsat!"** 
 - Si era l'últim acabar el joc amb un missatge final.

# 5. Estructura (Classe) **Vaixell**

S'ha de crear una estructura **Vaixell** amb el atributs:
 - nom
 - mida
 - tocades[]
 - orientacio
 
 El tipus de dada de cada atribut és lliure, trieu el que considereu més adequat.
 
 Si desenvolupeu aquesta opció, s’ha de:
  - Utilitzar aquesta estructura per representar cada vaixell.
  - Mostrar el nom del vaixell als missatges de resultat.
    - Exemple: 
      - **La Garota ha estat tocada!**
      - **La Garota ha estat tocada i enfonsada!**

# Puntuació total (10 punts)

| Apartat                           | Punts |
|-----------------------------------|:-----:|
| Menú i mode de joc                | **1** |
| Tauler + col·locació de vaixells | **2.5** |
| Tirades i tocat/aigua             | **2.5** |
| Enfonsament i final de partida    | **3** |
| Estrucutra **Vaixell**            | **1** |
| **TOTAL**                         | **10** |