public class Main {

    public static int[][] TaulellAmbBombes(int files, int columnes, int bombes) {
        int taulell[][] = new int[files][columnes];
        for (int i = 0; i < taulell.length; i++) {
            for (int j = 0; j < taulell[i].length; j++) {
                taulell[i][j] = 0;
            }
        }
        int contador = 0;
        while (contador < bombes) {
            int fila = Utils.nextRand(0, files - 1);
            int columna = Utils.nextRand(0, columnes - 1);
            if (taulell[fila][columna] == 0) {
                taulell[fila][columna] = -2;
                contador++;
            }
        }
        for (int i = 0; i < taulell.length; i++) {
            for (int j = 0; j < taulell[i].length; j++) {
                int num_bombes = 0;
                if (taulell[i][j] == -2) {
                    continue;
                }
                for (int ii = i - 1; ii < i + 2; ii++) {
                    for (int jj = j - 1; jj < j + 2; jj++) {
                        if (ii < 0 || jj < 0 || ii >= files || jj >= columnes) {
                            continue;
                        }
                        if (taulell[ii][jj] == -2) {
                            num_bombes++;
                        }
                    }
                }
                taulell[i][j] = num_bombes;
            }
        }
        return taulell;
    }

    public static void MostrarTaulell(int taulell[][], int taulellBandera[][]) {
        for (int i = 0; i < taulell[0].length; i++) {
            System.out.printf("%3d", i + 1);
        }
        System.out.println();
        for (int i = 0; i < taulell.length; i++) {
            System.out.printf("%d", i + 1);
            String ensenyar;
            for (int j = 0; j < taulell[i].length; j++) {
                if (taulellBandera[i][j] == -3) {
                    ensenyar = " 🚩";
                } else if (taulell[i][j] < 9 && taulell[i][j] >= 0 || taulell[i][j] == -2) {
                    ensenyar = "⬜​";
                } else if (taulell[i][j] == -1) {
                    ensenyar = " ";
                } else {
                    ensenyar = String.valueOf(taulell[i][j] - 8) + " ";
                }
                System.out.printf("%3s", ensenyar);
            }
            System.out.println();
        }
    }

    public static void MostrarTaulellPirata(int taulell[][]) {
        System.out.print("   ");
        for (int i = 0; i < taulell[0].length; i++) {
            System.out.printf("  %d", i + 1);
        }
        System.out.println();

        for (int i = 0; i < taulell.length; i++) {
            System.out.printf("%3d", i + 1);

            for (int j = 0; j < taulell[i].length; j++) {

                if (taulell[i][j] == -2) {
                    System.out.printf("%3s", "💣");
                } else if (taulell[i][j] > 0 && taulell[i][j] <= 8) {
                    System.out.printf("%3d", taulell[i][j]);
                } else if (taulell[i][j] > 8) {
                    System.out.printf("%3d", taulell[i][j] - 8);
                } else if (taulell[i][j] == 0 || taulell[i][j] == -1) {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }
    }

    public static int[][] Descobrir(int taulell[][], int fila_descobrir, int columna_descobrir) {
        int valor_casella = taulell[fila_descobrir][columna_descobrir];
        if (fila_descobrir < 0 || fila_descobrir >= taulell.length ||
                columna_descobrir < 0 || columna_descobrir >= taulell[0].length) {
            return taulell;
        }
        if (valor_casella >= 9 || valor_casella == -1 || valor_casella == -3) {
            return taulell;
        }
        if (valor_casella > 0 && valor_casella < 9) {
            taulell[fila_descobrir][columna_descobrir] = valor_casella + 8;
            return taulell;
        }
        if (valor_casella == 0) {
            taulell[fila_descobrir][columna_descobrir] = -1;
            for (int i = fila_descobrir - 1; i <= fila_descobrir + 1; i++) {
                for (int j = columna_descobrir - 1; j <= columna_descobrir + 1; j++) {
                    if (i >= 0 && i < taulell.length && j >= 0 && j < taulell[0].length) {
                        int veina = taulell[i][j];
                        if (!(veina == -1 || veina == -3 || veina >= 9)) {
                            Descobrir(taulell, i, j);
                        }
                    }
                }
            }
        }
        return taulell;
    }

    public static void main(String[] args) {
        int opció = Utils.nextInt(
                "Benvingut al buscamines, en quin mode vols jugar?\n1. Nivell 1\n(8x8 - 10 bombes)\n\n2. Nivell 2\n(16x20 - 50 bombes)\n\n3. Personalitzat\n(Esculls tu)\n\n4. Sortir\nLa teva opció: ");
        int files = 0;
        int columnes = 0;
        int bombes = 0;
        while (opció > 4 || opció < 1) {
            opció = Utils.nextInt("\nOpció no valida.");
        }
        while (opció != 4) {
            if (opció == 1 || opció == 2) {
                files = (opció == 1) ? 8 : 16;
                columnes = (opció == 1) ? 8 : 20;
                bombes = (opció == 1) ? 10 : 50;
            } else if (opció == 3) {
                files = Utils.nextInt("\nQuantes files voldràs?");
                columnes = Utils.nextInt("\nQuantes columnes voldràs?");
                bombes = Utils.nextInt("\nQuantes bombes voldràs?");
                if (bombes > files * columnes) {
                    bombes = files * columnes;
                }
            }
            int taulell[][] = TaulellAmbBombes(files, columnes, bombes);
            int taulellBandera[][] = new int[taulell.length][taulell[0].length];
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    taulellBandera[i][j] = 0;
                }
            }
            System.out.println("Creant el taulell");
            String punt = "";
            for (int i = 0; i < 4; i++) {
                punt = punt + ".";
                try {
                    Thread.sleep(750);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                System.out.println(punt);
            }

            System.out.println("Aqui tens el taulell:\n");
            MostrarTaulell(taulell, taulellBandera);
            int columna_descobrir = 0;
            long tempsInici = 0;
            boolean partidaIniciada = false;
            boolean TotesDescobertes = false;
            boolean BOMBAAAA = false;
            // INICI JOC
            while (!TotesDescobertes && !BOMBAAAA) {
                // Demanar mode/file/columna
                int fila_descobrir = Utils.nextInt("Quina fila vols descobrir? (0 per entrar en mode bandera)");
                if (fila_descobrir != 0 && fila_descobrir != -1) {
                    columna_descobrir = Utils.nextInt("Quina columna vols descobrir? ");
                    while (fila_descobrir < 1 || fila_descobrir > files || columna_descobrir < 1
                            || columna_descobrir > columnes) {
                        fila_descobrir = Utils.nextInt("Fila o columna fora de limits, torna a introduïr la fila: ");
                        columna_descobrir = Utils.nextInt("I ara la columna:  ");
                    }
                }
                // BANDERA
                if (fila_descobrir == 0) {
                    MostrarTaulell(taulell, taulellBandera);

                    while (true) {
                        fila_descobrir = Utils.nextInt("A quina fila vols posar/treure una bandera? (0 per sortir)");

                        if (fila_descobrir == 0) {
                            break;// sortir del mode banderes siuu
                        }
                        columna_descobrir = Utils.nextInt("A quina columna?");
                        if (fila_descobrir < 1 || fila_descobrir > files ||
                                columna_descobrir < 1 || columna_descobrir > columnes) {
                            System.out.println("Fora de límits.");
                            continue;
                        }
                        int f = fila_descobrir - 1;
                        int c = columna_descobrir - 1;
                        if (taulell[f][c] == -1 || taulell[f][c] >= 9) {
                            System.out.println("Aquesta casella ja està descoberta.");
                            continue;
                        }
                        if (taulellBandera[f][c] == -3) {
                            taulellBandera[f][c] = taulell[f][c];
                            System.out.println("Bandera retirada.");
                        } else {
                            taulellBandera[f][c] = -3;
                            System.out.println("Bandera col·locada.");
                        }
                        long tempsActual = System.currentTimeMillis();
                        long segons = (tempsActual - tempsInici) / 1000;
                        System.out.printf("Temps de partida: %d segons.\n", segons);
                        MostrarTaulell(taulell, taulellBandera);
                    }
                    continue;
                }
                // BANDERA
                // PIRATA
                else if (fila_descobrir == -1) {
                    MostrarTaulellPirata(taulell);
                    continue;
                }
                // BOMBA
                else if (taulellBandera[fila_descobrir - 1][columna_descobrir - 1] == -3) {
                    System.out.println("Has de treure la bandera abans de descobrir.");
                    continue;
                } else if (taulell[fila_descobrir - 1][columna_descobrir - 1] == -2) {
                    BOMBAAAA = true;
                } else if ((taulell[fila_descobrir - 1][columna_descobrir - 1] >= 9
                        && taulell[fila_descobrir - 1][columna_descobrir - 1] <= 16)
                        || taulell[fila_descobrir - 1][columna_descobrir - 1] == -1
                        || taulell[fila_descobrir - 1][columna_descobrir - 1] == -3) {
                    System.out.println("Aquesta casella ja ha sigut descoberta anteriorment!! Intenta una altre.\n");
                } else {
                    taulell = Descobrir(taulell, fila_descobrir - 1, columna_descobrir - 1);
                }
                if (!partidaIniciada) {
                    tempsInici = System.currentTimeMillis();
                    partidaIniciada = true;
                }
                if (partidaIniciada) {
                    long tempsActual = System.currentTimeMillis();
                    long segons = (tempsActual - tempsInici) / 1000;
                    System.out.printf("Temps de partida: %d segons.\n", segons);
                }
                MostrarTaulell(taulell, taulellBandera);
                TotesDescobertes = true;
                for (int i = 0; i < taulell.length; i++) {
                    for (int j = 0; j < taulell[i].length; j++) {
                        if (taulell[i][j] >= 0 && taulell[i][j] <= 8) {
                            TotesDescobertes = false;
                        }
                    }
                }
            }
            int puntuacio = 0;
            for (int i = 0; i < taulell.length; i++) {
                for (int j = 0; j < taulell[i].length; j++) {
                    if (taulell[i][j] >= 8 && taulell[i][j] <= 16) {
                        puntuacio = puntuacio + taulell[i][j] - 8;
                    }
                }
            }
            long tempsActual = System.currentTimeMillis();
            long segons = (tempsActual - tempsInici) / 1000;
            if (BOMBAAAA) {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                System.out.printf("Oh no!! Has tocat una bomba, la teva puntuació ha sigut de %d en %ld segons\n\n\n",
                        puntuacio, segons);
            } else if (TotesDescobertes) {
                System.out.printf(
                        "Felicitats!! Has descobert totes les caselles en nomes %d segons i amb una puntuació dé: %d.\n\n\n",
                        segons, puntuacio);
            }
            opció = Utils.nextInt(
                    "Fem una altre partideta o qué? En quin mode vols jugar?\n1. Nivell 1\n(8x8 - 10 bombes)\n\n2. Nivell 2\n(16x20 - 50 bombes)\n\n3. Personalitzat\n(Esculls tu)\n\n4. Sortir\nLa teva opció: ");
            while (opció > 4 || opció < 1) {
                opció = Utils.nextInt("\nOpció no valida.");
            }
        }
    }
}